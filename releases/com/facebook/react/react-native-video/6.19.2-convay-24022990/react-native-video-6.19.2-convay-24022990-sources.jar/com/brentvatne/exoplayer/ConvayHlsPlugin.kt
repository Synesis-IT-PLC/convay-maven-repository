package com.brentvatne.exoplayer

import android.net.Uri
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import com.brentvatne.common.api.Source

/**
 * Plugin that adds HLS token and exp as query parameters to every HTTP request,
 * matching convay-hls-player Android DataSourceUtils behavior (token in URL, not only headers).
 * Uses ExoPlayer/Media3 from this module; no extra app dependency.
 */
class ConvayHlsPlugin : RNVExoplayerPlugin {

    override fun overrideMediaDataSourceFactory(
        source: Source,
        mediaDataSourceFactory: DataSource.Factory
    ): DataSource.Factory? {
        // Always wrap so token is applied at request time (playlist + segments). If we return null
        // when !hasToken(), the default factory is used for the whole playback and segment requests never get the token.
        return ResolvingDataSource.Factory(mediaDataSourceFactory) { dataSpec ->
            resolveHlsTokenQuery(dataSpec)
        }
    }

    override fun onInstanceCreated(id: String, player: ExoPlayer) {}
    override fun onInstanceRemoved(id: String, player: ExoPlayer) {}

    private fun resolveHlsTokenQuery(dataSpec: DataSpec): DataSpec {
        val token = HlsTokenStore.token ?: return dataSpec
        val exp = HlsTokenStore.exp ?: return dataSpec
        if (token.isBlank() || exp.isBlank()) return dataSpec
        val uri = dataSpec.uri ?: return dataSpec
        if (uri.scheme != "http" && uri.scheme != "https") return dataSpec

        val builder = uri.buildUpon().clearQuery()
        for (name in uri.queryParameterNames) {
            if (name == HLS_TOKEN_QUERY || name == HLS_EXP_QUERY) continue
            for (value in uri.getQueryParameters(name)) {
                builder.appendQueryParameter(name, value)
            }
        }
        builder.appendQueryParameter(HLS_TOKEN_QUERY, token)
        builder.appendQueryParameter(HLS_EXP_QUERY, exp)
        val updatedUri = builder.build()
        return dataSpec.buildUpon().setUri(updatedUri).build()
    }

    companion object {
        private const val HLS_TOKEN_QUERY = "token"
        private const val HLS_EXP_QUERY = "exp"
    }
}
