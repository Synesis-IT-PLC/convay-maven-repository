package com.brentvatne.exoplayer

/**
 * Stores HLS token and expiry for use by the data source resolver.
 * Mirrors convay-hls-player Android DataSourceUtils.HlsTokenStore.
 * JS can update via HlsTokenModule.setHlsToken (app package).
 */
object HlsTokenStore {
    @Volatile
    var token: String? = null

    @Volatile
    var exp: String? = null

    fun update(newToken: String?, newExp: String?) {
        token = newToken
        exp = newExp
    }

    fun hasToken(): Boolean {
        return !token.isNullOrBlank() && !exp.isNullOrBlank()
    }
}
